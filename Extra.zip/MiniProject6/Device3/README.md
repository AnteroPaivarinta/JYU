Device: Router
Vendor: Zyxel.
Model: Not known
